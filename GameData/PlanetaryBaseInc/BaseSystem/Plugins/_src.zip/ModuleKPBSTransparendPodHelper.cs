﻿using UnityEngine;

namespace PlanetarySurfaceStructures
{
    class ModuleKPBSTransparendPodHelper : PartModule
    {
        /** The name of the transform to show when JSIATP is activated */
        [KSPField]
        public string additionalTransformName;

        //the module of the exdendable part
        private PlanetaryModule module;

        //the transform for an additional depthmask
        private Transform additionalTransform;

        //----------------methods-----------------

        
        /**
		 * Called at the start. Initialize the module
		 */
        public override void OnStart(PartModule.StartState state)
        {
            base.OnStart(state);

            //find the PlanetaryModule
            int count = part.Modules.Count;
            for (int i = 0; i < count; i++)
            {
                if (part.Modules[i] is PlanetaryModule)
                {
                    module = (PlanetaryModule)part.Modules[i];
                    break;
                }
            }
            //find the transform
            additionalTransform = part.internalModel.FindModelTransform(additionalTransformName);
        }
    }
}
